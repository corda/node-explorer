<Row >
    <Column cols={8}>
    <p>Toasts are dynamic messages that inform the user of an event that just happened or is going to happen.</p>
    </Column> 
</Row>

<div>
    <AnchorLink to="variations" offset={210}>
        Variations
    </AnchorLink>
    <AnchorLink to="alignment" offset={210}>
        Alignment
    </AnchorLink>
</div>

<Row >
    <Column cols={8}>
        <img src="../_img/toast--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="variations"><h2>Variations</h2></Anchor>
<h3>Colour</h3>
<Row >
    <Column cols={6}>
        <img src="../_img/toast--2.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/toast--3.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/toast--4.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/toast--5.png" />
    </Column> 
</Row>

<h3>Components</h3>
<Row >
    <Column cols={6}>
        <img src="../_img/toast--6.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/toast--7.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="alignment"><h2>Aligment</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/toast--8.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/toast--9.png" />
    </Column> 
</Row>