import '@testing-library/jest-dom/extend-expect';
export declare const createDocumentListenersMock: () => any;
