<Row >
    <Column cols={8}>
    <p>The top nav bar is a primary layout component. It could be used as a navigation in app with simple, flat architecture.</p>
    </Column> 
</Row>

<div>
    <AnchorLink to="spacing" offset={210}>
        Spacing
    </AnchorLink>
    <AnchorLink to="alignment" offset={210}>
        Alignment
    </AnchorLink>
</div>

<Row >
    <Column cols={12}>
        <img src="../_img/top-nav-bar--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="spacing"><h2>Spacing</h2></Anchor>
<Row >
    <Column cols={12}>
        <img src="../_img/top-nav-bar--2.png" />
    </Column> 
</Row>
<Row >
    <Column cols={12}>
        <img src="../_img/top-nav-bar--3.png" />
    </Column> 
</Row>
<Row >
    <Column cols={12}>
        <img src="../_img/top-nav-bar--4.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="alignment"><h2>Aligment</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/top-nav-bar--5.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/top-nav-bar--6.png" />
    </Column> 
</Row>