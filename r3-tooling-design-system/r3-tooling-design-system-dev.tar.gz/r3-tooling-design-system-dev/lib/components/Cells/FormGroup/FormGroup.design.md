<Row>
    <Column cols={8}>
        <p>Forms are the most common way for users to communicate with the system. Making sure that forms are easy to understand and complete is one of the most important tasks in creating user interfaces.</p>
        <Link to="../cells/form/design">
            <Button
                size="small"
                variant="tertiary"
                noPaddingFocus="tertiary">
                More about forms
            </Button>
        </Link>
    </Column>  
</Row>