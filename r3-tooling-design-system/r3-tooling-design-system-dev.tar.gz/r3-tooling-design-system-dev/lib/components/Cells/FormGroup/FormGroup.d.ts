import React from 'react';
interface Props {
    legend: string;
    className?: string;
    preview?: boolean;
    [x: string]: any;
}
declare const Form: React.FC<Props>;
export default Form;
