import React from 'react';
interface Props {
    active?: boolean;
    [x: string]: any;
}
declare const BreadcrumbItem: React.FC<Props>;
export default BreadcrumbItem;
