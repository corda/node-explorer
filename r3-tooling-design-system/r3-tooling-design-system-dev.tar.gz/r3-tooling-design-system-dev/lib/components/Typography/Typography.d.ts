import React from 'react';
declare const Typography: React.FC;
export default Typography;
