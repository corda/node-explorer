<div>
    <AnchorLink to="structure" offset={210}>
        Structure
    </AnchorLink>
    <AnchorLink to="states" offset={210}>
        States
    </AnchorLink>
</div>

<Row >
    <Column cols={6}>
        <img src="../_img/file-upload--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="structure"><h2>Structure</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/file-upload--2.png" />
        <ol>
        <li>Icon</li>
        <li>File name</li>
        <li>Progress</li>
        <li>Progress animation</li>
        </ol>
    </Column>
    <Column cols={6}>
        <img src="../_img/file-upload--3.png" />
        <ol>
        <li>Icon</li>
        <li>File name</li>
        <li>Remove icon</li>
        </ol>
    </Column> 
</Row>

<Anchor idToScrollTo="states"><h2>States</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/file-upload--4.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/file-upload--5.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/file-upload--6.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/file-upload--7.png" />
    </Column> 
</Row>