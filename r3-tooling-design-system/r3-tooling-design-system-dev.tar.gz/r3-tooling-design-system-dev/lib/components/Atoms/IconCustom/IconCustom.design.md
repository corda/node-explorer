<Row >
    <Column cols={8}>
    <p>For general design directions about icons, please see the Icons page in the Environment section.</p>
    <Link to="../environment/icons">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            More about Icons  
        </Button>
    </Link>
    </Column> 
</Row>
<Row >
    <Column cols={8} className="pt-4">
        <img src="../_img/icons--1.png" />
    </Column>
</Row>