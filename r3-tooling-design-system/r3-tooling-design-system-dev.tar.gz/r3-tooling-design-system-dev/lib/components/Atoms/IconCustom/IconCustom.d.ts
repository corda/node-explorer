import React from 'react';
interface Props {
    className?: string;
    icon: string;
    [x: string]: any;
}
declare const IconCustom: React.FunctionComponent<Props>;
export default IconCustom;
