<Row>
    <Column cols={8}>
        <p>The skeleton is an animated placeholder providing a vague preview of the loading content. Its purpose is to inform of the loading process and to reduce the load-time frustration in users.</p>
    </Column>  
</Row>

<Row>
    <Column cols={12}>
        <img src="../_img/skeleton--1.png" />
    </Column>
</Row>
<Row>
    <Column cols={6}>
        <img src="../_img/skeleton--2.png" />
    </Column>
    <Column cols={6}>
        <img src="../_img/skeleton--3.png" />
    </Column>
</Row>