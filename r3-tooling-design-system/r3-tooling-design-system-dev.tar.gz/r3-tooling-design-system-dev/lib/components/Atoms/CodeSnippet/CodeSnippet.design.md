<Row >
    <Column cols={8}>
    <p>Code snippets are used to display re-usable source code.</p>
    </Column> 
</Row>

<div>
    <AnchorLink to="variations" offset={210}>
        Variations
    </AnchorLink>
    <AnchorLink to="directions" offset={210}>
        Directions
    </AnchorLink>
</div>

<Row >
    <Column cols={6}>
        <img src="../_img/code-snippet--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="variations"><h2>Variations</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/code-snippet--2.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/code-snippet--3.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/code-snippet--4.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="directions"><h2>Directions</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/code-snippet--5.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/code-snippet--6.png" />
    </Column> 
</Row>