<Row >
    <Column cols={8}>
    <p>For general design directions about the grid, please see the Grid and layout instructions.</p>
    <Link to="../environment/grid-and-layout/design">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            Grid and layout   
        </Button>
    </Link>
    </Column> 
</Row>
<Row >
    <Column cols={8} className="pt-4">
        <img src="../_img/gird-and-layout--9.png" />
    </Column>
</Row>