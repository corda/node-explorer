import React from 'react';
interface Props {
    className?: string;
    [x: string]: any;
}
declare const Row: React.FC<Props>;
export default Row;
