<Anchor idToScrollTo="properties"><h3>Properties</h3></Anchor>

| Property    | Type   | Required? | Notes                                                                                                                    |
| :---------- | :----- | :-------- | :----------------------------------------------------------------------------------------------------------------------- |
| className   | string | no        |                                                                                                                          |
| Other Props | any    | no        | Any other props that a `<div>` element can take. These will be applied to the wrapping `<div>` element of the component. |
