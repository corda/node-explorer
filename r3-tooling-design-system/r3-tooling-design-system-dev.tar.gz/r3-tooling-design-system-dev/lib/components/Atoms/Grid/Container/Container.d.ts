import React from 'react';
interface Props {
    className?: string;
    fluid?: boolean;
    [x: string]: any;
}
declare const Container: React.FC<Props>;
export default Container;
