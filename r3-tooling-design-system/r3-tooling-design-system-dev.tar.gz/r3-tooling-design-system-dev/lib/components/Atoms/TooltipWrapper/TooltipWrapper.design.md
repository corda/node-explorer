<Row >
    <Column cols={8}>
    <p>For design information about tooltips check out the atom's page.</p>
    <Link to="../atoms/Tooltip/design">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            More about tooltips
        </Button>
    </Link>
    </Column> 
</Row>
<Row >
    <Column cols={6} className="pt-4">
        <img src="../_img/tooltip--1.png" />
    </Column>
</Row>