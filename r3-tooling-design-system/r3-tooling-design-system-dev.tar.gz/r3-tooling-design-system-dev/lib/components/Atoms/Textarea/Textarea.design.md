<Row >
    <Column cols={8}>
    <p>The text area allows longer text input from the user. Styles and UI are similar to the regular text input.</p>
    <Link to="../atoms/TextInput/design">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            More about Inputs
        </Button>
    </Link>
    </Column> 
</Row>

<Row >
    <Column cols={6} className="pt-4">
        <img src="../_img/text-area--1.png" />
    </Column>
</Row>