<Row >
    <Column cols={8}>
    <p>Icon buttons inherit the general styles of regular buttons. They could be used when the action behind the icon is implicit and could not be mistaken.</p>
    <Link to="../atoms/Button/design">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            More about Buttons
        </Button>
    </Link>
    </Column> 
</Row>

<Row >
    <Column cols={4} className="pt-4">
        <img src="../_img/icon-button--1.png" />
    </Column> 
        <Column cols={4}>
        <img src="../_img/icon-button--2.png" />
    </Column> 
        <Column cols={4}>
        <img src="../_img/icon-button--3.png" />
    </Column> 
</Row>

<Row >
    <Column cols={4}>
        <img src="../_img/icon-button--4.png" />
    </Column> 
        <Column cols={4}>
        <img src="../_img/icon-button--5.png" />
    </Column> 
        <Column cols={4}>
        <img src="../_img/icon-button--6.png" />
    </Column> 
</Row>