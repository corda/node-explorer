<Row >
    <Column cols={8}>
    <p>Phone inputs are used instead of regular inputs when a phone number is required from the user. Styles and UI are identical to the regular text input.</p>
    <Link to="../atoms/TextInput/design">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            More about Inputs
        </Button>
    </Link>
    </Column> 
</Row>

<Row >
    <Column cols={6} className="pt-4">
        <img src="../_img/phone-input--1.png" />
    </Column>
</Row>