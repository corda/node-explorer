<Row >
    <Column cols={8}>
    <p>Alerts are used for on-age system feedback. They can be placed for success/error messages in forms, bellow the fields. They could be used to worn the user about an update or a change, above the content of a page.</p>
    </Column> 
</Row>

<div>
    <AnchorLink to="variations" offset={210}>
        Variations
    </AnchorLink>
    <AnchorLink to="spacing" offset={210}>
        Spacing
    </AnchorLink>
    <AnchorLink to="usage" offset={210}>
        Usage
    </AnchorLink>
    <AnchorLink to="alignment" offset={210}>
        Alignment
    </AnchorLink>
</div>

<Row >
    <Column cols={12}>
        <img src="../_img/alert--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="variations"><h2>Variations</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--2.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/alert--3.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--4.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="spacing"><h2>Spacing</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--5.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/alert--6.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--7.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="usage"><h2>Usage</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--8.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/alert--9.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="alignment"><h2>Aligment</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--10.png" />
    </Column> 
    <Column cols={6}>
        <img src="../_img/alert--11.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/alert--12.png" />
    </Column> 
</Row>