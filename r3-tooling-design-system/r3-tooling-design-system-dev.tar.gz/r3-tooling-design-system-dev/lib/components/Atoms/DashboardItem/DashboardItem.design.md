<Row >
    <Column cols={8}>
    <p>Dashboard items are used to list any type of items in a grid. You can place from 3 to 6 atoms on a single row.  Choose a custom image or a pictogram from the system. You can use the component with or without a light grey background.</p>
    </Column> 
</Row>

<div>
    <AnchorLink to="variations" offset={210}>
        Variations
    </AnchorLink>
    <AnchorLink to="spacing" offset={210}>
        Spacing
    </AnchorLink>
    <AnchorLink to="stacking" offset={210}>
        Stacking
    </AnchorLink>
</div>

<Row >
    <Column cols={6}>
        <img src="../_img/dashboard-item--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="variations"><h2>Variations</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/dashboard-item--2.png" />
    </Column> 
     <Column cols={6}>
        <img src="../_img/dashboard-item--3.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="spacing"><h2>Spacing</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/dashboard-item--4.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="stacking"><h2>Stacking</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/dashboard-item--5.png" />
    </Column> 
     <Column cols={6}>
        <img src="../_img/dashboard-item--6.png" />
    </Column> 
</Row>
<Row >
    <Column cols={6}>
        <img src="../_img/dashboard-item--7.png" />
    </Column> 
     <Column cols={6}>
        <img src="../_img/dashboard-item--8.png" />
    </Column> 
</Row>