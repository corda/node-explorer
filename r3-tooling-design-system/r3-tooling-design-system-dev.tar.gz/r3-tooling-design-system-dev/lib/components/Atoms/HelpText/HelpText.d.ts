import React from 'react';
interface Props {
    helpText: string;
}
declare const HelpText: React.FC<Props>;
export default HelpText;
