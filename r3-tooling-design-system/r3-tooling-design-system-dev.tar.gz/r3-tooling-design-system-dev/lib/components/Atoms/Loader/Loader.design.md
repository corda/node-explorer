<div>
    <AnchorLink to="spacing" offset={210}>
        Spacing
    </AnchorLink>
    <AnchorLink to="alignment" offset={210}>
        Alignment 
    </AnchorLink>
</div>

<Row >
    <Column cols={6}>
        <img src="../_img/loader--1.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="spacing"><h2>Spacing</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/loader--2.png" />
    </Column> 
</Row>

<Anchor idToScrollTo="alignment"><h2>Alignment</h2></Anchor>
<Row >
    <Column cols={6}>
        <img src="../_img/loader--3.png" />
    </Column> 
     <Column cols={6}>
        <img src="../_img/loader--4.png" />
    </Column> 
</Row>

