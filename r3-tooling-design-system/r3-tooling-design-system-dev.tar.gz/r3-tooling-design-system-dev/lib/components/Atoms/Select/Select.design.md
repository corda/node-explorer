<Row >
    <Column cols={8}>
    <p>The select is a simple form atom allows the user to select one from a predefined list of option. Styles and UI are similar to the regular text input.</p>
    <Link to="../atoms/TextInput/design">
        <Button
            size="small"
            variant="tertiary"
            noPaddingFocus="tertiary">
            More about Inputs
        </Button>
    </Link>
    </Column> 
</Row>

<Row >
    <Column cols={6} className="pt-4">
        <img src="../_img/select--1.png" />
    </Column> 
</Row>