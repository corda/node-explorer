import React from 'react';
interface Props {
    errorMessage: string;
}
declare const ErrorMessage: React.FC<Props>;
export default ErrorMessage;
