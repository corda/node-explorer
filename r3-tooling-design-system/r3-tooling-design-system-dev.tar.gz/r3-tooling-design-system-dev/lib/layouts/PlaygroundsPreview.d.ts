import React from 'react';
declare const PlaygroundsPreview: React.FC;
export default PlaygroundsPreview;
