import React from 'react';
declare const DasboardExample: React.FC;
export default DasboardExample;
