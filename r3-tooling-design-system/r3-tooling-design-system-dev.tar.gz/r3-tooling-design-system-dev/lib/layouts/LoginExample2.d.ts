import React from 'react';
declare const LoginExample2: React.FC;
export default LoginExample2;
