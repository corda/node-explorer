import React from 'react';
declare const LoginExample3: React.FC;
export default LoginExample3;
