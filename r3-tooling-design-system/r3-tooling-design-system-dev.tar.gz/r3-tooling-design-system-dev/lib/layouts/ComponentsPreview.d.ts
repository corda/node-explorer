import React from 'react';
declare const ExamplesComponent: React.FC;
export default ExamplesComponent;
