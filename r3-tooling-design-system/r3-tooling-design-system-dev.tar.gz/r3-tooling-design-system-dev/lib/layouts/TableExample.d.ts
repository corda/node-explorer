import React from 'react';
declare const TableExample: React.FC;
export default TableExample;
