import React from 'react';
declare const ChangePasswordExample: React.FC;
export default ChangePasswordExample;
