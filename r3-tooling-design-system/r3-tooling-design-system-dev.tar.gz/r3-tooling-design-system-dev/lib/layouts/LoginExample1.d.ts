import React from 'react';
declare const LoginExample1: React.FC;
export default LoginExample1;
